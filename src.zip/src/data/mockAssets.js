const mockAssets = [
  {
    id: '1',
    name: 'RaptorNFT #1',
    description: 'Este es un asset único en la blockchain de Raptoreum.',
    image: 'https://ipfsweb.raptoreum.com/ipfs/QmU4S3bg6dNtGZjXgM8bR2B4sPsmzapZeojVd7oUFzEiPF',
  },
  {
    id: '2',
    name: 'RaptorNFT #2',
    description: 'Otro asset coleccionable increíble.',
    image: 'https://ipfsweb.raptoreum.com/ipfs/QmU4S3bg6dNtGZjXgM8bR2B4sPsmzapZeojVd7oUFzEiPF',
  },
  {
    id: '3',
    name: 'RaptorNFT #3',
    description: 'Un NFT memorable para la historia de Raptoreum.',
    image: 'https://ipfsweb.raptoreum.com/ipfs/QmeePtbYW4QgFfTc1nss5og5fXQqhiCsvdHRby33QYWWx6',
  },
];

export default mockAssets;
