import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Box } from '@chakra-ui/react';
import Navbar from './Components/Navbar';
import { jwtDecode } from 'jwt-decode';
import Home from './Pages/Home';
import AssetDetail from './Pages/AssetDetails';
import Login from './Pages/Login';
import Signup from './Pages/Signup';


function isTokenValid(token) {
  try {
    const decoded = jwtDecode(token);
    // Comprueba si el token ha expirado
    if (decoded.exp && Date.now() >= decoded.exp * 1000) {
      return false;
    }
    return true;
  } catch (e) {
    return false;
  }
}

function PrivateRoute({ children }) {
  const token = localStorage.getItem('token');
  const valid = token && isTokenValid(token);
  return valid ? children : <Navigate to="/login" replace />;
}

function App() {
  return (
    <Router>
      <Box minH="100vh" bg="gray.50">
        <Navbar />
        <Box p={4}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route
              path="/"
              element={
                <PrivateRoute>
                  <Home />
                </PrivateRoute>
              }
            />
            <Route
              path="/asset/:id"
              element={
                <PrivateRoute>
                  <AssetDetail />
                </PrivateRoute>
              }
            />
          </Routes>
        </Box>
      </Box>
    </Router>
  );
}

export default App;